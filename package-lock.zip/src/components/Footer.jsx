import React from 'react'

const Footer = () => {
  return (
    <React.Fragment>
        <div className='pt-11 pb-8 bg-slate-600 '>
       hello
        </div>
    </React.Fragment>
  )
}

export default Footer